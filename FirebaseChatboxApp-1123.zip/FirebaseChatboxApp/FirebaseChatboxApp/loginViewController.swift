import UIKit

class loginViewController: UIViewController {
    
    // A variable to store the currently logged-in user's name
    static var name: String = ""
    @IBOutlet weak var myimage: UIImageView!
    var imagelist:[String] = ["1","2","3","4","5","6","7","8","9","10"]
    var namelist:[String] = [
        "ShadowHunter",
        "NightmareWizard",
        "MysticKnight",
        "ThunderFury",
        "DragonSlayer",
        "PhoenixRider",
        "SilverWolf",
        "DarkValkyrie",
        "ArcaneSorcerer",
        "StormChaser"
    ]


    @IBOutlet weak var myname: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Add tap gesture to dismiss keyboard when tapping anywhere on the screen
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture1)
    }
    
    @IBAction func loginTapped(_ sender: Any) {
        if let username = myname.text, !username.isEmpty {
            // If the text field is not empty, proceed to the next screen
            loginViewController.name = self.myname.text!
            self.performSegue(withIdentifier: "showmain", sender: true)
        } else {
            // Show an alert if the text field is empty
            showAlert(title: "Error", message: "Please enter your username.")
        }
    }

    
    @IBAction func random(_ sender: Any) {
        let randomIndex = Int(arc4random_uniform(UInt32(namelist.count)))
        myname.text = namelist[randomIndex]
    
        // Update the image based on the random selection
        let randomImageName = imagelist[randomIndex]
        myimage.image = UIImage(named: randomImageName)
    }

    
    // Function to dismiss the keyboard
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    // Function to show an alert
    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
}
