//
//  ViewController.swift
//  FirebaseChatboxApp
//
//  Created by student on 23/11/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

