//
//  MyProfileViewController.swift
//  FirebaseChatboxApp
//
//  Created by student on 23/11/2024.
//

import UIKit

class MyProfileViewController: UIViewController {

    @IBOutlet weak var name: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        self.name.text = loginViewController.name
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
