import UIKit
import Firebase
import FirebaseFirestore
import FirebaseFirestoreSwift

class ChatListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var chatid: String?
    var roomname: String?
    
    @IBOutlet weak var theTable: UITableView!
    @IBOutlet weak var roomnamestring: UILabel!
    
    var messages: [Message] = [] // 存储消息对象
    @IBOutlet weak var sendmessagetext: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Display the roomname in the label
        if let roomname = roomname {
            roomnamestring.text = "Room Name: " + roomname
        }

        // Print chatid for debugging purposes
        if let chatid = chatid {
            print("ChatID: \(chatid)")
            // 加载消息
            loadMessages()
        }

        // Do any additional setup after loading the view.
    }

    // MARK: - TableView DataSource Methods

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChatListTableViewCell", for: indexPath) as! ChatListTableViewCell
        let message = messages[indexPath.row]
        cell.usernameTxt.text = message.username
        cell.timeTxt.text =   message.message + " " + formatTimestamp(message.timestamp)
      //  cell.messageTxt.text = message.message // 显示消息内容
        return cell
    }
    
    // MARK: - Send Message Action
    
    @IBAction func sentTapped(_ sender: Any) {
        guard let messageText = sendmessagetext.text, !messageText.isEmpty else {
            return // 如果输入框为空，则不执行任何操作
        }
        
        guard let chatid = chatid else { return }

        // 获取当前时间戳
        let timestamp = Timestamp(date: Date())

        // 假设你有一个方法来获取当前用户名
        let username = loginViewController.name // 这里可以改成获取当前登录用户的用户名

        // 创建一个 Message 对象
        let message = Message(username: username, message: messageText, timestamp: timestamp)

        // Firestore 操作
        let db = Firestore.firestore()
        
        // 尝试更新文档数据，如果文档不存在，则创建一个新文档
        let docRef = db.collection("teams").document(chatid)

        docRef.getDocument { (document, error) in
            if let error = error {
                print("Error checking document: \(error)")
            } else {
                if let document = document, document.exists {
                    // 如果文档已存在，更新消息数组
                    docRef.updateData([
                        "messages": FieldValue.arrayUnion([[
                            "username": message.username,
                            "message": message.message,
                            "timestamp": message.timestamp
                        ]])
                    ]) { error in
                        if let error = error {
                            print("Error sending message: \(error)")
                        } else {
                            print("Message sent successfully")
                            self.sendmessagetext.text = "" // 清空输入框
                        }
                    }
                } else {
                    // 如果文档不存在，创建新文档并添加消息
                    docRef.setData([
                        "messages": [
                            [
                                "username": message.username,
                                "message": message.message,
                                "timestamp": message.timestamp
                            ]
                        ]
                    ]) { error in
                        if let error = error {
                            print("Error creating document: \(error)")
                        } else {
                            print("New chat room created and message added")
                            self.sendmessagetext.text = "" // 清空输入框
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - Load Messages from Firebase

    func loadMessages() {
        guard let chatid = chatid else { return }

        // Firestore 监听消息的集合
        let db = Firestore.firestore()
        db.collection("teams").document(chatid)
            .addSnapshotListener { [weak self] snapshot, error in
                if let error = error {
                    print("Error loading messages: \(error)")
                    return
                }
                
                guard let snapshot = snapshot, let data = snapshot.data() else { return }
                
                // 清空消息数组
                self?.messages.removeAll()

                // 获取消息数组
                if let messageArray = data["messages"] as? [[String: Any]] {
                    for messageData in messageArray {
                        if let username = messageData["username"] as? String,
                           let message = messageData["message"] as? String,
                           let timestamp = messageData["timestamp"] as? Timestamp {
                            let message = Message(username: username, message: message, timestamp: timestamp)
                            self?.messages.append(message)
                        }
                    }
                }

                // 刷新 tableView
                self?.theTable.reloadData()
            }
    }

    // MARK: - Helper Methods

    func formatTimestamp(_ timestamp: Timestamp) -> String {
        let date = timestamp.dateValue()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        return dateFormatter.string(from: date)
    }
}
