
import UIKit

class CustomBubbleDataSomeone: customBubbleData {

    override init() {
        super.init()
        
       // type = .Someone
    }
}
