import Foundation
import MessageKit

struct Sender: SenderType {
  let senderId: String
  let displayName: String
}
