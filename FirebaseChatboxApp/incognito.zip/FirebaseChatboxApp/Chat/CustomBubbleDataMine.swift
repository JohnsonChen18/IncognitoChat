
import UIKit

class CustomBubbleDataMine: customBubbleData {

    override init() {
        super.init()
        
      //  self.userDataType = .me
        self.userDataType = .me
    }
}
